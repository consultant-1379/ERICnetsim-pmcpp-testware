#!/usr/bin/python
################################################################################
# COPYRIGHT Ericsson 2017
#
# The copyright to the computer program(s) herein is the property of
# Ericsson Inc. The programs may be used and/or copied only with written
# permission from Ericsson Inc. or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the
# program(s) have been supplied.
################################################################################

###################################################
# NSS Release    :  17.7
# Purpose        :  End to end Genstats setup for single simulation
# Jira No       :  NSS-11521, NSS-11522
# Gerrit Link   :  https://gerrit.ericsson.se/#/c/2304796/
# Description   :  Added auto detection facility of simulation list
# Date          :  4/28/2017
# Last Modified :  arwa.nawab@tcs.com
####################################################


import sys
import getopt
import socket
import os
from time import gmtime, strftime
from subprocess import Popen, PIPE
from shutil import copyfile
import getSimulationData as NetsimInfo
import TemplateGenerator as genTemplates
import DataAndStringConstants as Constants
import FetchDeltaSimList as deltaSims


# This method is used to fetch information i.e node type,node name, MIM version corresponding to given simulation
# once these details available we will generate ROPs, file for given node.
def generateTemplates(sim_list,stats_dir):
    # generate template file
    os.system("rm -rf /pms_tmpfs/xml_step/*/*.xml")
    sim_map = NetsimInfo.generate_sim_data(sim_list)
    for sim in sim_map:
        node_info = sim_map[sim]
        node_type = node_name = mim = mib = mim_ver = sim_data = Constants.EMPTY_STRING

        for node in node_info:
            node_info_list = node.split()
            node_name = node_info_list[0]
            node_type = node_info_list[2].upper()
            sim_mim_ver = node_info_list[3].upper()
            mim_ver = sim_mim_ver
            mim = NetsimInfo.get_mim_file(node_type, mim_ver)
            if node_type in genTemplates.ECIM_NODES_TYPES:
                mib = NetsimInfo.get_mib_file(node_type, mim_ver)
                if not mib:
                    print getCurrentDateTime() + ' ERROR : MIB file is not present for -> ' + sim
                    sys.exit(1)
        if not mim:
            print getCurrentDateTime() + ' ERROR : MIM file is not present for -> ' + sim
            sys.exit(1)
        #sim_data.txt formation
        if not stats_dir:
            stats_dir = Constants.DEFAULT_PM_DATA_LOCATION
        sim_data = ["sim_name: " + sim + " node_name: " + node_name + " node_type: " + node_type + " sim_mim_ver: " + mim_ver + " stats_dir: " + stats_dir + " trace: " + stats_dir + " mim: " + mim +" mib: " + mib+ ""]

        if not mib:
            # generate cpp cfg and template files
            cpp_cfg_map = genTemplates.generate_cpp_cfg_map(sim_data)
            for cfg_file, mim_file in cpp_cfg_map.iteritems():
                print getCurrentDateTime() + " INFO : Generating CPP templates"
                genTemplates.generate_cpp_cfg_file(cfg_file, mim_file)
                genTemplates.generate_cpp_template_files(cfg_file, mim_file)
        else:
            # generate ecim cfg and template files
            ecim_cfg_map = genTemplates.generate_ecim_cfg_map(sim_data)
            for cfg_file, schema_file in ecim_cfg_map.iteritems():
                print getCurrentDateTime() + " INFO : Generating COM/ECIM templates"
                mim_file = schema_file[0]
                mib_file = schema_file[1]
                genTemplates.generate_ecim_cfg_file(cfg_file, mib_file)
                genTemplates.generate_ecim_template_file(cfg_file, mim_file, mib_file)

    if Constants.LTE in sim:
        sim_ID = sim.split()[-1].split('-')[-1]
        if Constants.LTE in sim_ID:
            sim=sim_ID
    elif Constants.RNC in sim:
        sim_ID = sim.split()[-1].split('-')[-1]
        if Constants.RNC in sim_ID:
            sim=sim_ID

    rollout_xml_templates = "/netsim_users/pms/bin/rollout_xml_templates.sh -n " + sim
    print getCurrentDateTime() + " INFO : Generating templates at /netsim_users/pms/xml_templates"
    run_shell_command(rollout_xml_templates)


def setup(sim_list,stats_dir):
    for sim in sim_list:
        settmpfs = "/netsim_users/pms/bin/settmpfs.sh " + sim
        print getCurrentDateTime() + " INFO : Creating directory structure within /pms_tmpfs/ for -> " + sim
        run_shell_command(settmpfs)

def run_shell_command(command):
    command_output = Popen(command, stdout=PIPE, shell=True).communicate()[0]
    return command_output


# This method is responsible foe updating netsim_cfg file and also responsible to call pm_setup_stats_recordings.sh once the templates is generated.
def updateCfg(sim_list,stats_dir):
    for sim_name in sim_list:
        print getCurrentDateTime() + " Adding entry in netsim_cfg for sim -> " + sim_name
        hostName = run_shell_command("hostname").strip()
        hostNameUpdated = hostName.replace("-", "_")

		# Process the simulation names if it is LTE or RNC
        if Constants.LTE in sim_name:
            sim_ID = sim_name.split()[-1].split('-')[-1]
            if Constants.LTE in sim_ID:

                sim_name = sim_ID
        elif Constants.RNC in sim_name:
            sim_ID = sim_name.split()[-1].split('-')[-1]
            if Constants.RNC in sim_ID:
                sim_name = sim_ID

        command = "cat " + Constants.NETSIM_CFG_FILE + " | grep -w {0}".format(sim_name)
        output_value = run_shell_command(command).strip()
        if not output_value:
            fin = open(Constants.NETSIM_CFG_FILE)
            fout = open("tmp", "wt")
            mme_list = hostNameUpdated + "_mme_list"
            other_list = hostNameUpdated + "_list"
            for line in fin:
                if Constants.SGSN in sim_name:
                    fout.write( line.replace(mme_list+'=\"', mme_list+'=\"'+sim_name+" ") )
                else:
                    fout.write( line.replace(other_list+'=\"', other_list+'=\"'+sim_name+" ") )
        #if stats_dir:
            #fout.write('\n'+node_name+"_PM_FileLocation="+stats_dir)
            fin.close()
            fout.close()
            os.rename("tmp", Constants.NETSIM_CFG_FILE)  # Rename the new file
def getCurrentDateTime():
    return strftime("%Y-%m-%d %H:%M:%S", gmtime())

#This is start point of this script that take two arguments as an parameters one is simulation and another one is
#real path location and process according to that.
def main(argv):

   simList = Constants.EMPTY_STRING
   stats_dir = Constants.EMPTY_STRING
   isDirSetup = False
   isCfgUpdate = False
   isGenerate = False
   autoDetect = False

   if (len(argv) < 2):
      print 'USAGE : RolloutSims.py --sim_list <comma separated sim list> --auto_detect <Automatic detect the delta simulations> --path <real file path for stats_dir>[OPTIONAL] --templates <Set True for template generation> --dirSetup <Set it True if Directory creation within /pms_tmpfs is required>[OPTIONAL] --cfgUpdate <Set it True if sim name needs to be added in netsim_cfg>[OPTIONAL]'
      sys.exit(1)
   try:
      opts, args = getopt.getopt(argv,"help:sim_list:path:templates:dirSetup:cfgUpdate:auto_detect",["sim_list=","path=","templates=","dirSetup=","cfgUpdate=","auto_detect="])
   except getopt.GetoptError:
      print 'USAGE : RolloutSims.py --sim_list <comma separated sim list> --auto_detect <Automatic detect the delta simulations> --path <real file path for stats_dir>[OPTIONAL] --templates <Set True for template generation> --dirSetup <Set it True if Directory creation within /pms_tmpfs is required>[OPTIONAL] --cfgUpdate <Set it True if sim name needs to be added in netsim_cfg>[OPTIONAL]'
      sys.exit(1)
   for opt, arg in opts:
      if opt == '-help':
         print 'USAGE : RolloutSims.py --sim_list <comma separated sim list> --auto_detect <Automatic detect the delta simulations> --path <real file path for stats_dir>[OPTIONAL] --templates <Set True for template generation> --dirSetup <Set it True if Directory creation within /pms_tmpfs is required>[OPTIONAL] --cfgUpdate <Set it True if sim name needs to be added in netsim_cfg>[OPTIONAL]'
         sys.exit(1)
      elif opt in ("--sim_list"):
         simList = arg.split(" ")
      elif opt in ("--auto_detect"):
         autoDetect = arg.split(" ")
      elif opt in ("--path"):
         stats_dir = arg
      elif opt in ("--templates"):
         isGenerate = arg
      elif opt in ("--dirSetup"):
         isDirSetup = arg
      elif opt in ("--cfgUpdate"):
         isCfgUpdate = arg

   if autoDetect:
      simList = deltaSims.main()
   if not simList:
      print "No Simulations provided / No Delta Simulations found"
      sys.exit(1)

   if isGenerate:
      generateTemplates(simList,stats_dir)
   if isDirSetup:
      setup(simList,stats_dir)
   if isCfgUpdate:
      updateCfg(simList,stats_dir)


if __name__ == "__main__":
   main(sys.argv[1:])
